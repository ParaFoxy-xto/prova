# Projeto de Métodos de Programação - MP

- FrontEnd: Foi utilizado em HTML, CSS e Bootstrap

- BackEnd: Foi desenvolvido em Python+Django


